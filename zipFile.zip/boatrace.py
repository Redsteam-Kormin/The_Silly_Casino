import os, sys, time, random
from os import system
from time import sleep as s
name = 0
def clear():
    if name == 'nt':
        _ = system('cls')
    
    else:
        _ = system('clear')

racernames = ["Jimmy Stix", "Bob Gleeger", "Steve Grumbo", "Sunny Farthington", "Walt.", "Clark Randomguy", "Blatant Reference", "I hate this boat, man.", "Number Three with fries and a Coke", "The Skrizzler", "Hammyhuzz", "Mounster"]

racer1 = racernames[random.randint(0,11)]
#racer 2
racer2 = racernames[random.randint(0,11)]
while racer2 == racer1:
    racer2 = racernames[random.randint(0,11)]
#racer 3
racer3 = racernames[random.randint(0,11)]
while racer3 == racer1:
    racer3 = racernames[random.randint(0,11)]
    while racer3 == racer2:
        racer3 = racernames[random.randint(0,11)]
#racer 4
racer4 = racernames[random.randint(0,11)]
while racer4 == racer1:
    racer4 = racernames[random.randint(0,11)]
    while racer4 == racer2:
        racer4 = racernames[random.randint(0,11)]
        while racer4 == racer3:
            racer4 = racernames[random.randint(0,11)]
#racer 5
racer5 = racernames[random.randint(0,11)]
while racer5 == racer1:
    racer5 = racernames[random.randint(0,11)]
    while racer5 == racer2:
        racer5 = racernames[random.randint(0,11)]
        while racer5 == racer3:
            racer5 = racernames[random.randint(0,11)]
            while racer5 == racer4:
                racer5 = racernames[random.randint(0,11)]

def race(money,startmoney):
    winner = 0
    place1 = 0
    global moneychange
    moneychange = 0
    #what racer did they bet on?
    if betnum == 1:
        betracer = racer1
    elif betnum == 2:
        betracer = racer2
    elif betnum == 3:
        betracer = racer3
    elif betnum == 4:
        betracer = racer4
    elif betnum == 5:
        betracer = racer5
    move1 = 0
    move2 = 0
    move3 = 0
    move4 = 0
    move5 = 0
    #start
    while 1:
        #movement checks
        move1 += random.randint(1,10)
        move2 += random.randint(1,10)
        move3 += random.randint(1,10)
        move4 += random.randint(1,10)
        move5 += random.randint(1,10)
        print("Moving...")
        s(0.2)
        #move placements
        #1st Place racer
        if move1 > move2 and move1 > move3 and move1 > move4 and move1 > move5:
            place1 = racer1
        elif move2 > move1 and move2 > move3 and move2 > move4 and move2 > move5:
            place1 = racer2
        elif move3 > move1 and move3 > move2 and move3 > move4 and move3 > move5:
            place1 = racer3
        elif move4 > move1 and move4 > move3 and move4 > move2 and move2 > move5:
            place1 = racer4
        elif move5 > move1 and move5 > move3 and move5 > move4 and move5 > move2:
            place1 = racer5
        else:
            print("nobody is in first place yet...")
        print(place1, "is winning.")
        s(1)
        
        if move1 >= 50:
            break
            print(racer1, " ,Racer 1 Wins!")
            if betnum == 1:
                money = money + (bet*2)
            else:
                money -= bet
        elif move2 >= 50:
            break
            print(racer2, " ,Racer 2 Wins!")
            if betnum == 2:
                money = money + (bet*2)
            else:
                money -= bet
        elif move3 >= 50:
            break
            print(racer3, " ,Racer 3 Wins!")
            if betnum == 3:
                money = money + (bet*2)
            else:
                money -= bet
        elif move4 >= 50:
            break
            print(racer4, " ,Racer 4 Wins!")
            if betnum == 4:
                money = money + (bet*2)
            else:
                money -= bet
        elif move5 >= 50:
            break
            print(racer5, " ,Racer 5 Wins!")
            if betnum == 5:
                money = money + (bet*2)
            else:
                money -= bet
    if betracer == place1:
        print("You lost ",startmoney - money, " dollars.")
    elif betracer == 0:
        print("how did you manage to not lose or win? are you just that bad?")
    elif betracer != place1:
        print("You made ", money-startmoney, " dollars.")
    s(1.5)

clear()
print("Welcome to funny boat race gambling simulator")
username = str(input("Your name? "))
while 1:
    clear()
    print("   -=Difficulty=-  ")
    print("1| Easy: 10000")
    print("2| Medium: 1000")
    print("3| Hard: 100")
    print("4| Broke: 10")
    print("5| Alcoholic: 1")
    dfchoose = int(input("Choose a difficulty (enter it's number): "))
    if dfchoose == 1:
        money = 10000
        df = "Easy"
        break
    elif dfchoose == 2:
        money = 1000
        df = "Medium"
        break
    elif dfchoose == 3:
        money = 100
        df = "Hard"
        break
    elif dfchoose == 4:
        money = 10
        df = "Broke"
        break
    elif dfchoose == 5:
        money = 1
        df = "Alcoholic"
        break
    else:
        print("uhhh. no?")

print("The goal is to get to 1,000,000.")
print("Or you can play infinitely.")
print("1| Infinite ")
print("0| Normal")
inf = int(input('Infinite or Not? '))
if inf == 1:
    goal = 9999999999999999999999999999999999999999
else:
    goal = 1000000

while money != goal:
    clear()
    #betting menu
    print("  -",username,"-")
    print("Money: ",money)
    print("")
    print("1| ", racer1)
    print("2| ", racer2)
    print("3| ", racer3)
    print("4| ", racer4)
    print("5| ", racer5)
    while 1:
        betnum = int(input("What Number Racer will you bet on? "))
        if betnum == 1 or betnum == 2 or betnum == 3 or betnum == 4 or betnum == 5:
            break
        else:
            print("thats not a racer bud.")
    while 1:
        bet = int(input("How much will you bet? "))
        if bet <= money:
            break
        else:
            print("You're too broke for that haha")
    startmoney = money
    race(money,startmoney)

    #money gained/lost
    